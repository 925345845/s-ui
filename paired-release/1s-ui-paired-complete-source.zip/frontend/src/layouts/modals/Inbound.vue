<template>
  <v-dialog transition="dialog-bottom-transition" width="800" @after-enter="updateData(id)">
    <v-card class="rounded-lg" :loading="loading">
      <v-card-title>
        {{ $t('actions.' + title) + " " + $t('objects.inbound') }}
      </v-card-title>
      <v-divider></v-divider>
      <v-skeleton-loader
          class="mx-auto border"
          width="95%"
          type="card, text, divider, list-item-two-line"
          v-if="loading"
        ></v-skeleton-loader>
      <v-card-text style="padding: 0 16px; overflow-y: scroll;">
        <v-container style="padding: 0;" :hidden="loading">
          <v-row>
            <v-col cols="12" sm="6" md="4">
              <v-select
                hide-details
                label="Core"
                :items="coreItems"
                v-model="inbound.core_type"
                @update:modelValue="changeCore">
              </v-select>
            </v-col>
            <v-col cols="12" sm="6" md="4">
              <v-select
              hide-details
              :label="$t('type')"
              :items="inboundTypeItems"
              v-model="inbound.type"
              @update:modelValue="changeType">
              </v-select>
            </v-col>
            <v-col cols="12" sm="6" md="4">
              <v-text-field v-model="inbound.tag" :label="$t('objects.tag')" hide-details></v-text-field>
            </v-col>
          </v-row>
          <v-tabs
            v-if="HasInData.includes(inbound.type)"
            v-model="side"
            density="compact"
            fixed-tabs
            align-tabs="center"
          >
            <v-tab value="s">{{ $t('in.sSide') }}</v-tab>
            <v-tab value="c">{{ $t('in.cSide') }}</v-tab>
          </v-tabs>
          <v-window v-model="side" style="margin-top: 10px;">
            <v-window-item value="s">
              <Listen :data="inbound" :inTags="inTags" v-if="inbound.type != inTypes.Tun" />
              <Direct v-if="inbound.type == inTypes.Direct" :data="inbound" />
              <Shadowsocks v-if="inbound.type == inTypes.Shadowsocks" direction="in" :data="inbound" />
              <Hysteria v-if="inbound.type == inTypes.Hysteria" direction="in" :data="inbound" />
              <Hysteria2 v-if="inbound.type == inTypes.Hysteria2 && !isXray" direction="in" :data="inbound" />
              <XrayHysteria2 v-if="inbound.type == inTypes.Hysteria2 && isXray" :data="inbound" />
              <Naive v-if="inbound.type == inTypes.Naive" direction="in" :data="inbound" />
              <ShadowTls v-if="inbound.type == inTypes.ShadowTLS" direction="in" :data="inbound" />
              <Tuic v-if="inbound.type == inTypes.TUIC" direction="in" :data="inbound" />
              <Tun v-if="inbound.type == inTypes.Tun" :data="inbound" />
              <AnyTls v-if="inbound.type == inTypes.AnyTls" :data="inbound" direction="in" />
              <TProxy v-if="inbound.type == inTypes.TProxy" :inbound="inbound" />
              <DokodemoDoor v-if="inbound.type == inTypes.DokodemoDoor" :data="inbound" />
              <Wireguard v-if="inbound.type == inTypes.WireGuard" :data="inbound" />
              <XrayTransport v-if="isXray && inbound.type != inTypes.Hysteria2 && inbound.type != inTypes.WireGuard && inbound.type != inTypes.DokodemoDoor && Object.hasOwn(inbound,'transport')" :data="inbound" />
              <Transport v-else-if="Object.hasOwn(inbound,'transport')" :data="inbound" />
              <Users v-if="hasUser" :clients="clients" :data="initUsers" />
              <InTls v-if="hasTlsPanel"  :inbound="inbound" :tlsConfigs="tlsConfigs" :tls_id="inbound.tls_id" />
              <Multiplex v-if="!isXray && MuxAvailable.includes(inbound.type)" direction="in" :data="inbound" />
            </v-window-item>
            <v-window-item value="c">
              <OutJsonVue v-if="!isXray" :inData="inbound" :type="inbound.type" />
              <Multiplex v-if="!isXray && Object.hasOwn(inbound,'multiplex')" direction="out" :data="inbound.out_json" />
              <Dial v-if="!isXray && inbound.out_json" :dial="inbound.out_json" mode="client" />
              <v-card>
                <v-card-text>
                  <v-card-subtitle>{{ $t('in.multiDomain') }}
                    <v-chip color="primary" density="compact" variant="elevated" @click="add_addr"><v-icon icon="mdi-plus" /></v-chip>
                  </v-card-subtitle>
                  <template v-for="addr,index in inbound.addrs">
                    {{ $t('in.addr') }} #{{ (index+1) }} <v-icon icon="mdi-delete" color="error" @click="inbound.addrs?.splice(index,1)" />
                    <v-divider></v-divider>
                    <AddrVue :addr="addr" :hasTls="hasTlsPanel" />
                  </template>
                </v-card-text>
              </v-card>
            </v-window-item>
          </v-window>
        </v-container>
      </v-card-text>
      <v-card-actions>
        <v-spacer></v-spacer>
        <v-btn
          color="primary"
          variant="outlined"
          @click="closeModal"
        >
          {{ $t('actions.close') }}
        </v-btn>
        <v-btn
          color="primary"
          variant="tonal"
          :loading="loading"
          @click="saveChanges"
        >
          {{ $t('actions.save') }}
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script lang="ts">
import { CoreTypes, InTypes, createInbound, Addr, ShadowTLS } from '@/types/inbounds'
import RandomUtil from '@/plugins/randomUtil'
import Dial from '@/components/Dial.vue'
import Listen from '@/components/Listen.vue'
import Direct from '@/components/protocols/Direct.vue'
import Users from '@/components/Users.vue'
import Shadowsocks from '@/components/protocols/Shadowsocks.vue'
import Hysteria from '@/components/protocols/Hysteria.vue'
import Hysteria2 from '@/components/protocols/Hysteria2.vue'
import Naive from '@/components/protocols/Naive.vue'
import ShadowTls from '@/components/protocols/ShadowTls.vue'
import Tuic from '@/components/protocols/Tuic.vue'
import Tun from '@/components/protocols/Tun.vue'
import AnyTls from '@/components/protocols/AnyTls.vue'
import InTls from '@/components/tls/InTLS.vue'
import TProxy from '@/components/protocols/TProxy.vue'
import DokodemoDoor from '@/components/protocols/DokodemoDoor.vue'
import Wireguard from '@/components/protocols/Wireguard.vue'
import XrayHysteria2 from '@/components/protocols/XrayHysteria2.vue'
import Multiplex from '@/components/Multiplex.vue'
import Transport from '@/components/Transport.vue'
import XrayTransport from '@/components/XrayTransport.vue'
import AddrVue from '@/components/Addr.vue'
import OutJsonVue from '@/components/OutJson.vue'
import Data from '@/store/modules/data'

const isOpenWrtLite = import.meta.env.VITE_OPENWRT_LITE === 'true'

export default {
  props: ['visible', 'id', 'inTags', 'tlsConfigs', 'dataSource', 'connectionHost'],
  emits: ['close'],
  data() {
    return {
      inbound: createInbound("direct",{ id:0, "tag": "" }),
      title: "add",
      loading: false,
      side: "s",
      coreTypes: CoreTypes,
      coreItems: isOpenWrtLite
        ? [{ title: 'sing-box', value: CoreTypes.SingBox }]
        : [
            { title: 'sing-box', value: CoreTypes.SingBox },
            { title: 'Xray-core', value: CoreTypes.Xray },
          ],
      inTypes: InTypes,
      inboundWithUsers: ['mixed', 'socks', 'http', 'shadowsocks', 'vmess', 'trojan', 'naive', 'hysteria', 'shadowtls', 'tuic', 'hysteria2', 'vless', 'anytls'],
      initUsers: {
        model: 'none',
        values: <any>[],
      },
      HasInData: [
        InTypes.SOCKS,
        InTypes.HTTP,
        InTypes.Mixed,
        InTypes.Shadowsocks,
        InTypes.VMess,
        InTypes.ShadowTLS,
        InTypes.Trojan,
        InTypes.Hysteria,
        InTypes.VLESS,
        InTypes.AnyTls,
        InTypes.TUIC,
        InTypes.Hysteria2,
        InTypes.Naive,
      ],
      HasTls: [
        InTypes.HTTP,
        InTypes.VMess,
        InTypes.Trojan,
        InTypes.Naive,
        InTypes.Hysteria,
        InTypes.TUIC,
        InTypes.Hysteria2,
        InTypes.VLESS,
        InTypes.AnyTls,
      ],
      MuxAvailable: [
        InTypes.VLESS,
        InTypes.VMess,
        InTypes.Trojan,
        InTypes.Shadowsocks,
      ],
      xrayTypeItems: [
        { title: 'VLESS', value: InTypes.VLESS },
        { title: 'VMess', value: InTypes.VMess },
        { title: 'Trojan', value: InTypes.Trojan },
        { title: 'Shadowsocks', value: InTypes.Shadowsocks },
        { title: 'SOCKS', value: InTypes.SOCKS },
        { title: 'HTTP', value: InTypes.HTTP },
        { title: 'Mixed', value: InTypes.Mixed },
        { title: 'Hysteria2', value: InTypes.Hysteria2 },
        { title: 'Dokodemo-door', value: InTypes.DokodemoDoor },
        { title: 'WireGuard', value: InTypes.WireGuard },
      ],
      OnlyTLS: [InTypes.Hysteria, InTypes.Hysteria2, InTypes.TUIC, InTypes.Naive, InTypes.AnyTls ],
    }
  },
  methods: {
    async loadData(id: number) {
      this.loading = true
      const inboundArray = this.dataSource?.loadInbounds
        ? await this.dataSource.loadInbounds([id])
        : await Data().loadInbounds([id])
      this.inbound = inboundArray[0]
      if (this.HasInData.includes(this.inbound.type) && this.inbound.out_json == null) {
        this.inbound.out_json = {}
      }
      this.loading = false
    },
    updateData(id: number) {
      if (id > 0) {
        this.loadData(id)
        this.title = "edit"
      }
      else {
        const port = RandomUtil.randomIntRange(10000, 60000)
        this.inbound = createInbound("direct",{ id: 0, core_type: CoreTypes.SingBox, tag: "direct-"+port ,listen: "::", listen_port: port }, this.effectiveHost)
        if (this.HasInData.includes(this.inbound.type)){
          this.inbound.addrs = []
          this.inbound.out_json = {}
        } else {
          delete this.inbound.addrs
          delete this.inbound.out_json
        }
        this.title = "add"
        this.loading = false
      }
      this.side = "s"
      this.initUsers = {
        model: 'none',
        values: [],
      }
    },
    changeCore() {
      if (!this.inbound.listen_port) this.inbound.listen_port = RandomUtil.randomIntRange(10000, 60000)
      if (this.isXray && !this.xrayTypeItems.some((item) => item.value == this.inbound.type)) {
        this.inbound.type = InTypes.VLESS
      }
      this.changeType()
    },
    changeType() {
      if (!this.inbound.listen_port) this.inbound.listen_port = RandomUtil.randomIntRange(10000, 60000)
      // Tag change only in add inbound
      const tag = this.$props.id > 0 ? this.inbound.tag : this.inbound.type + "-" + this.inbound.listen_port
      // Use previous data
      const prevConfig = { id: this.inbound.id, core_type: this.inbound.core_type, tag: tag, listen: this.inbound.listen?? "::", listen_port: this.inbound.listen_port }
      this.inbound = createInbound(this.inbound.type, this.inbound.type != this.inTypes.Tun ? prevConfig : { tag: tag }, this.effectiveHost)
      if (this.HasInData.includes(this.inbound.type)){
        this.inbound.addrs = []
        this.inbound.out_json = {}
      } else {
        delete this.inbound.addrs
        delete this.inbound.out_json
      }
      this.side = "s"
    },
    add_addr() {
      this.inbound.addrs?.push(<Addr>{ server: this.effectiveHost, server_port: this.inbound.listen_port })
    },
    closeModal() {
      this.updateData(0) // reset
      this.$emit('close')
    },
    async saveChanges() {
      if (!this.$props.visible) return
      // check duplicate tag
      const isDuplicatedTag = this.dataSource?.checkTag
        ? this.dataSource.checkTag(this.inbound.id, this.inbound.tag)
        : Data().checkTag("inbound", this.inbound.id, this.inbound.tag)
      if (isDuplicatedTag) return

      // save data
      this.loading = true
      let clientIds = []
      if (this.hasUser) {
        switch (this.initUsers.model) {
          case 'all':
            clientIds = this.clients.map((c:any) => c.id)
            break
          case 'group':
            clientIds = this.clients.filter((c:any) => this.initUsers.values.includes(c.group)).map((c:any) => c.id)
            break
          case 'client':
            clientIds = this.initUsers.values
        }
      }
      const success = this.dataSource?.save
        ? await this.dataSource.save(this.$props.id == 0 ? "new" : "edit", this.inbound, clientIds)
        : await Data().save("inbounds", this.$props.id == 0 ? "new" : "edit", this.inbound, clientIds)
      if (success) this.closeModal()
      this.loading = false
    },
  },
  computed: {
    validate() {
      if (this.inbound == undefined) return false
      if (this.inbound.tag == "") return false
      if (this.inbound.listen_port > 65535 || this.inbound.listen_port < 1) return false
      if (this.OnlyTLS.includes(this.inbound.type) && this.inbound.tls_id == 0) return false
      return true
    },
    isXray() {
      return this.inbound.core_type == CoreTypes.Xray
    },
    inboundTypeItems() {
      if (this.isXray) {
        return this.xrayTypeItems
      }
      return Object.keys(this.inTypes)
        .map((key,index) => ({title: key, value: Object.values(this.inTypes)[index]}))
        .filter((item) => item.value != InTypes.DokodemoDoor && item.value != InTypes.WireGuard)
    },
    hasTlsPanel() {
      if (this.isXray) {
        // Stream-level TLS/Reality for proxy inbounds; SOCKS/HTTP/Mixed optional.
        return [InTypes.VLESS, InTypes.VMess, InTypes.Trojan, InTypes.Hysteria2, InTypes.SOCKS, InTypes.HTTP, InTypes.Mixed].includes(this.inbound.type)
      }
      return this.HasTls.includes(this.inbound.type)
    },
    clients() {
      return this.dataSource?.clients ?? Data().clients ?? []
    },
    effectiveHost() {
      return this.connectionHost || location.hostname
    },
    hasUser() {
      if (this.$props.id > 0) return false
      if (!this.inboundWithUsers.includes(this.inbound.type)) return false
      if (this.inbound.type == InTypes.ShadowTLS && (<ShadowTLS>this.inbound).version < 3 ) return false
      if ((<any>this.inbound).managed) return false
      return true
    },
  },
  watch: {
    visible(newValue) {
      if (newValue) {
        this.loading = true
      }
    },
  },
  components: {
    Listen, InTls, Hysteria2, Naive, Direct, Shadowsocks,
    Users, Hysteria, ShadowTls, TProxy, Multiplex, Tuic, Tun,
    AnyTls, Transport, XrayTransport, AddrVue, OutJsonVue, Dial, DokodemoDoor, Wireguard, XrayHysteria2
  }
}
</script>
